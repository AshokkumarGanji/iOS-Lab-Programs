//
//  ViewController.swift
//  Vavilala_CalculatorApp
//
//  Created by Chandan  on 9/16/23.
//
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var currentOperand = ""
    var currentOperator: String?
    var previousOperand = ""
    
    @IBAction func ButtonAllClear(_ sender: Any) {
        
        currentOperand = ""
        currentOperator = nil
        previousOperand = ""
        resultOutlet.text = ""
    }
    
    
    @IBAction func ButtonClear(_ sender: Any) {
        currentOperand = ""
        resultOutlet.text = ""
    }
    
   
    @IBAction func integer(_ sender: UIButton) {
        
        if let digit = sender.titleLabel?.text{
            currentOperand += digit
            resultOutlet.text = currentOperand
            
        }
    }
    
    
    @IBAction func ButtonAddition(_ sender: Any) {
        handleOperator("+")
        
    }
    
    
    @IBAction func ButtonSubstraction(_ sender: Any) {
        handleOperator("-")
    }
    
    
    @IBAction func ButtonMultiplication(_ sender: Any) {
        handleOperator("*")
    }
    
    
    @IBAction func ButtonDivision(_ sender: Any) {
        handleOperator("/")
    }
    
    
    @IBAction func ButtonEquals(_ sender: Any) {
        performCalculation()
        
    }
    
    
    @IBAction func ButtonModulo(_ sender: Any) {
        handleOperator("%")
    }
    
    
    @IBAction func ButtonDecimal(_ sender: Any) {
        if !currentOperand.contains("."){
            currentOperand += "."
            resultOutlet.text = currentOperand
        }
    }
    
    
    @IBAction func ButtonZero(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    @IBAction func ButtonOne(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    @IBAction func ButtonTwo(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    @IBAction func ButtonThree(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    @IBAction func ButtonFour(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    @IBAction func ButtonFive(_ sender: Any) {
        
        integer(sender as! UIButton)
        
    }
    
    
    @IBAction func ButtonSix(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    @IBAction func ButtonSeven(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    
    @IBAction func ButtonEight(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    
    @IBAction func ButtonNine(_ sender: Any) {
        integer(sender as! UIButton)
    }
    
    
    func handleOperator(_ operatorSymbol: String) {
        if !currentOperand.isEmpty {
            currentOperator = operatorSymbol
            previousOperand = currentOperand
            currentOperand = ""
            resultOutlet.text = ""
        }
    }
    
    
    func performCalculation(){
        if let operatorSymbol = currentOperator,!currentOperand.isEmpty {
            let operand1 = Double(previousOperand) ?? 0.0
            let operand2 = Double(currentOperand) ?? 0.0
            
            var result: Double = 0.0
            
            switch operatorSymbol {
            case "+":
                result = operand1 + operand2
                
            case "-":
                result = operand1 - operand2
                
            case "*":
                result = operand1 * operand2
                
            case "/":
                if operand2 != 0{
                    result = operand1/operand2
                }
                else{
                    resultOutlet.text = "Not a Number"
                    return
                }
                
            case "%":
                if operand2 != 0 {
                    result = operand1.truncatingRemainder(dividingBy: operand2)
                    
                }
                else{
                    resultOutlet.text = "Error"
                    return
                }
            default:
                break
            }
            currentOperand = String(result)
            currentOperator = nil
            previousOperand = currentOperand
            resultOutlet.text = currentOperand
        }
        
    }
    
    
}
